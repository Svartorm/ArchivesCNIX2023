#! /bin/sh

touch AUTHORS
echo 'Hugo
Frangiamone
hugo.frangiamone' > AUTHORS
chmod 640 AUTHORS
